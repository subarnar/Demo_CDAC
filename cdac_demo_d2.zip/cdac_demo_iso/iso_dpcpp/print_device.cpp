#include "iso3dfd.h"

void print_device(queue& q){

}

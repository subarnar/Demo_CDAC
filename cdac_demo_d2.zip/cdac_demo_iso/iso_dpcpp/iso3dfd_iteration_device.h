
#ifndef iso_ite
#define iso_ite
#include "iso3dfd.h"

void iso3dfd_iteration_device(cl::sycl::nd_item<3> it, float *next,
        float *prev, float *vel, const float *coeff,
        size_t nx, size_t nxy, size_t bx, size_t by, size_t bz) {

        //Fill the next line
        size_t gid = it.get_global_id(0) + HALF_LENGTH + (it.get_global_id(1)+HALF_LENGTH)*nx + (it.get_global_id(2)+HALF_LENGTH)*nxy; 

        float value = coeff[0] * prev[gid];
        for (unsigned int iter = 1; iter <= HALF_LENGTH; iter++)
        {
                value += coeff[iter] *  (prev[gid + iter] + prev[gid - iter]);
                value += coeff[iter] * (prev[gid + iter*nxy] + prev[gid - iter*nxy]);
                value += coeff[iter] * (prev[gid + iter*nx] + prev[gid - iter*nx]);
        }
        next[gid] = 2.0f*prev[gid] - next[gid] + value * vel[gid];
}

#endif
//==============================================================
// Copyright © 2019 Intel Corporation
//
// SPDX-License-Identifier: MIT
// =============================================================

#include <iostream>
#include "iso3dfd.h"
#include "iso_def.h"


/*
 * Host-Code
 * Main function to drive the sample application
 */
int main(int argc, char* argv[]) {

	float* prev_base;
	float* next_base;
	float* vel_base;
	float* temp;

	bool check = false;
	bool error = false;
	bool isGPU = false;

	size_t n1, n2, n3;
	size_t n1_Tblock, n2_Tblock, n3_Tblock;
	unsigned int nIterations;

	try {
		n1 = std::stoi(argv[1])+ (2 * HALF_LENGTH);
		n2 = std::stoi(argv[2]) + (2 * HALF_LENGTH);
		n3 = std::stoi(argv[3]) + (2 * HALF_LENGTH);
		n1_Tblock = std::stoi(argv[4]);
		n2_Tblock = std::stoi(argv[5]);
		n3_Tblock = std::stoi(argv[6]);
		nIterations = std::stoi(argv[7]);
	}
	catch (...) {
		usage(argv[0]);
		return 1;
	}
	for (unsigned int arg = 8; arg < argc; arg++) {

                if (std::string(argv[arg]) == "check") {
                        check = true;
                }
		if(std::string(argv[arg]) == "gpu") {
                        isGPU = true;
                }
        }


	if (checkGridDimension(n1 - 2 * HALF_LENGTH, n2 - 2 * HALF_LENGTH, n3 - 2 * HALF_LENGTH, n1_Tblock, n2_Tblock, n3_Tblock))
	{
		usage(argv[0]);
		return 1;
	}

	size_t nsize = n1 * n2 * n3;

	prev_base = new float[nsize];
	next_base = new float[nsize];
	vel_base = new float[nsize];

	float coeff[HALF_LENGTH + 1] = {
		-3.0548446,
		+1.7777778,
		-3.1111111e-1,
		+7.572087e-2,
#if (HALF_LENGTH == 4)
		- 1.76767677e-2
#elif (HALF_LENGTH == 8)
		- 1.76767677e-2,
		+3.480962e-3,
		-5.180005e-4,
		+5.074287e-5,
		-2.42812e-6
#endif
	};

	//Apply the DX DY and DZ to coefficients
	coeff[0] = (3.0f*coeff[0]) / (DXYZ*DXYZ);
	for (int i = 1; i <= HALF_LENGTH; i++) {
		coeff[i] = coeff[i] / (DXYZ*DXYZ);
	}

	std::cout << " ***** Running SYCL variant *****" << std::endl;
	initialize(prev_base, next_base, vel_base, n1, n2, n3);

/*Section of interest starts here*/

	/*Starting our DPCPP implementation*/
	auto start = std::chrono::steady_clock::now();
	device_selector *sel = NULL;
	//fill the function set_selector
	set_selector(&sel, isGPU);
	//fill the function create_queue
	queue q = create_queue(*sel);

/*Section of interest ends here */

	//Calling the propagation function
	iso_3dfd_main(q, next_base, prev_base, vel_base, coeff, n1, n2, n3, n1_Tblock, n2_Tblock, n3_Tblock, nIterations);
	q.wait_and_throw();

	auto end = std::chrono::steady_clock::now();
	auto time = std::chrono::duration_cast<std::chrono::milliseconds>(end - start).count();
	std::cout << "SYCL time: " << time << " ms" << std::endl;

	printStats(time, n1, n2, n3, nIterations);




	if(check){
		/*Checking results*/
		temp = new float[nsize];
		if (nIterations % 2)
			memcpy(temp, next_base, nsize * sizeof(float));
		else
			memcpy(temp, prev_base, nsize * sizeof(float));
	
	
		initialize(prev_base, next_base, vel_base, n1, n2, n3);
	
		std::cout << "Grid Sizes: " << n1 - 2 * HALF_LENGTH << " " << n2 - 2 * HALF_LENGTH << " " << n3 - 2 * HALF_LENGTH << std::endl;
		std::cout << "Memory Usage: " << ((3 * nsize * sizeof(float)) / (1024 * 1024)) << " MB" << std::endl;
	
	
		/*Running the serial variant for checking results*/
		std::cout << " ***** Running C++ Serial variant *****" << std::endl;
	
		start = std::chrono::steady_clock::now();
	
		iso_3dfd(next_base, prev_base, vel_base, coeff, n1, n2, n3, nIterations, n1_Tblock, n2_Tblock, n3_Tblock);
	
		end = std::chrono::steady_clock::now();
		time = std::chrono::duration_cast<std::chrono::milliseconds>(end - start).count();
	
		printStats(time, n1, n2, n3, nIterations);
	
	
	
		if (nIterations % 2) {
			error = within_epsilon(next_base, temp, n1, n2, n3, HALF_LENGTH, 0, 0.1f);
			if (error) std::cout << "Error  = " << error << std::endl;
			else std::cout<<"Results validated"<<std::endl;
		}
		else {
			error = within_epsilon(prev_base, temp, n1, n2, n3, HALF_LENGTH, 0, 0.1f);
			if (error) std::cout << "Error  = " << error << std::endl;
			else std::cout<<"Results validated"<<std::endl;
		}
		delete[] temp;
	}

	delete sel;

	delete[] prev_base;
	delete[] next_base;
	delete[] vel_base;
	
	return error ? 1 : 0;
}
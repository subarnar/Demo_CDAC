//==============================================================
// Copyright © 2019 Intel Corporation
//
// SPDX-License-Identifier: MIT
// =============================================================

#include <CL/sycl.hpp>
using namespace cl::sycl;

#include <chrono>
#include <cmath>
#include <ctime>
#include <cstring>


/*
 * ND-Range Kernel workgroup sizes optimal for different variants of
 * the kernel executing on GPU device
 * 
 * DIMX: work-items in first dimension of work-group
 * DIMY: work-items in second dimension of work-group 
 * BLOCKZ: Number of slices across the z-dimension
 * This can be used to vary the global work-items in ND-Range Kernel
 */
#define DIMX 32
#define DIMY 8
#define BLOCKZ 64

/*
 * Parameters to define coefficients
 * HALF_LENGTH: Radius of the stencil
 * Sample source code is tested for HALF_LENGTH=8 resulting in 
 * 16th order Stencil finite difference kernel 
 */
#define DT 0.002f
#define DXYZ 50.0f
#define HALF_LENGTH 8

/*
 * Padding to test and eliminate shared local memory bank conflicts for
 * the shared local memory(slm) version of the kernel executing on GPU
 */
#define PAD 0 

/*
 * ND-Range Kernel workgroup sizes optimal for ND-Range kernel executing
 * on CPU device
 */
#define DIMX_CPU 256
#define DIMY_CPU 1
#define BLOCKZ_CPU 64 

bool iso_3dfd_main(cl::sycl::queue& q, float* ptr_next, float* ptr_prev, float* ptr_vel, float* ptr_coeff,
        size_t n1, size_t n2, size_t n3,
        size_t bx, size_t by, size_t bz, unsigned int nIterations); 

bool iso_3dfd_cpu(cl::sycl::queue& , float* , float* , float* , float* ,
	size_t , size_t , size_t ,
	size_t , size_t , size_t , unsigned int ) ;	

void printTargetInfo(cl::sycl::queue& , unsigned int , unsigned int );
	
void usage(std::string);

void printStats(double , size_t , size_t , size_t , unsigned int );

bool within_epsilon(float* , float *, const size_t , const size_t , const size_t , const unsigned int , const int , const float);

bool checkGridDimension(size_t , size_t , size_t , unsigned int, unsigned int, unsigned int );


void set_selector(device_selector **sel, bool isGPU);
queue create_queue(device_selector& sel);
void print_device(queue& q);

//==============================================================
// Copyright © 2019 Intel Corporation
//
// SPDX-License-Identifier: MIT
// =============================================================

#include <CL/sycl.hpp>
using namespace cl::sycl;

#include <chrono>
#include <cmath>
#include <ctime>
#include <cstring>
#include "iso3dfd.h"



#define MIN(a,b) (a) < (b) ? (a) : (b)

//using namespace cl::sycl;

/*
 * Host-Code
 * Function used for initialization
 */
void initialize(float* ptr_prev, float* ptr_next, float* ptr_vel, size_t n1, size_t n2, size_t n3) {
        std::cout << "Initializing ... " << std::endl;
        size_t dim2 = n2 * n1;
        for (size_t i = 0; i < n3; i++) {
                for (size_t j = 0; j < n2; j++) {
                        size_t offset = i * dim2 + j * n1;

                        for (int k = 0; k < n1; k++) {
                                ptr_prev[offset + k] = 0.0f;
                                ptr_next[offset + k] = 0.0f;
                                ptr_vel[offset + k] = 2250000.0f*DT*DT;//Integration of the v*v and dt*dt
                        }
                }
        }
        //Then we add a source
        float val = 1.f;
        for (int s = 5; s >= 0; s--) {
                for (int i = n3 / 2 - s; i < n3 / 2 + s; i++) {
                        for (int j = n2 / 4 - s; j < n2 / 4 + s; j++) {
                                size_t offset = i * dim2 + j * n1;
                                for (int k = n1 / 4 - s; k < n1 / 4 + s; k++) {
                                        ptr_prev[offset + k] = val;
                                }
                        }
                }
                val *= 10;
        }

}

void iso_3dfd_it(float *ptr_next_base, float *ptr_prev_base, float *ptr_vel_base,
        float *coeff, const size_t n1, const size_t n2, const size_t n3,
        const size_t n1_Tblock, const size_t n2_Tblock, const size_t n3_Tblock) {

        size_t dimn1n2 = n1 * n2;
        size_t n3End = n3 - HALF_LENGTH;
        size_t n2End = n2 - HALF_LENGTH;
        size_t n1End = n1 - HALF_LENGTH;

        for (size_t bz = HALF_LENGTH; bz < n3End; bz += n3_Tblock) {    //start of cache blocking
                for (size_t by = HALF_LENGTH; by < n2End; by += n2_Tblock) {
                        for (size_t bx = HALF_LENGTH; bx < n1End; bx += n1_Tblock) {
                                int izEnd = MIN(bz + n3_Tblock, n3End);
                                int iyEnd = MIN(by + n2_Tblock, n2End);
                                int ixEnd = MIN(n1_Tblock, n1End - bx);
                                int ix;
                                for (size_t iz = bz; iz < izEnd; iz++) { //start of inner iterations
                                        for (size_t iy = by; iy < iyEnd; iy++) {
                                                float* ptr_next = ptr_next_base + iz * dimn1n2 + iy * n1 + bx;
                                                float* ptr_prev = ptr_prev_base + iz * dimn1n2 + iy * n1 + bx;
                                                float* ptr_vel = ptr_vel_base + iz * dimn1n2 + iy * n1 + bx;
                                                for (size_t ix = 0; ix < ixEnd; ix++) {
                                                        float value = 0.0;
                                                        value += ptr_prev[ix] * coeff[0];
                                                        for (unsigned int ir = 1; ir <= HALF_LENGTH; ir++) {

                                                                value += coeff[ir] * ((ptr_prev[ix + ir] + ptr_prev[ix - ir]) +
                                                                        (ptr_prev[ix + ir * n1] + ptr_prev[ix - ir * n1]) +
                                                                        (ptr_prev[ix + ir * dimn1n2] + ptr_prev[ix - ir * dimn1n2]));
                                                        }
                                                        ptr_next[ix] = 2.0f* ptr_prev[ix] - ptr_next[ix] + value * ptr_vel[ix];
                                                }
                                        }
                                }//end of inner iterations
                        }
                }
        }//end of cache blocking
}


/*
 * Host-Code
 * Driver function for ISO3DFD OpenMP code
 * Uses ptr_next and ptr_prev as ping-pong buffers to achieve
 * accelerated wave propogation
 */
void iso_3dfd(float *ptr_next, float *ptr_prev, float *ptr_vel, float *coeff,
        const size_t n1, const size_t n2, const size_t n3, const unsigned int nreps,
        const size_t n1_Tblock, const size_t n2_Tblock, const size_t n3_Tblock) {

        for (unsigned int it = 0; it < nreps; it += 1) {

                iso_3dfd_it(ptr_next, ptr_prev, ptr_vel, coeff,
                        n1, n2, n3, n1_Tblock, n2_Tblock, n3_Tblock);

                // here's where boundary conditions and halo exchanges happen
                // Swap previous & next between iterations
                it++;
                if (it < nreps)
                        iso_3dfd_it(ptr_prev, ptr_next, ptr_vel, coeff,
                                n1, n2, n3, n1_Tblock, n2_Tblock, n3_Tblock);
        } // time loop
}

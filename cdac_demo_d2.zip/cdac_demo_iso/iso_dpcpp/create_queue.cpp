
#include "iso3dfd.h"

/*
    This function takes as input a device_selector reference. At this stage, you already specified the instanciation of
    your device selector (previous step).
*/
queue create_queue(device_selector& sel){
    //Modify the next line to set up the queue correctly
	queue q(sel);
	return q;
}
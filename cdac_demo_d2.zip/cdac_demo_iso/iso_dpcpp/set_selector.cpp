
#include "iso3dfd.h"

void set_selector(device_selector **sel, bool isGPU){
	if(isGPU){
		*sel= new gpu_selector();//You need to correctly fill this line with a selector that will target the GPU
	}else{
		*sel= new cpu_selector();//You need to correctly fill this line with a selector that will target the CPU
	}
}
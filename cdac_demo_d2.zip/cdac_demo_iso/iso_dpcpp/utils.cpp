//==============================================================
// Copyright © 2019 Intel Corporation
//
// SPDX-License-Identifier: MIT
// =============================================================

#include "iso3dfd.h"

bool checkGridDimension(size_t n1, size_t n2, size_t n3, unsigned int dimX, unsigned int dimY, unsigned int blockZ){
	if((n1)%dimX){
		std::cout << " ERROR: Invalid Grid Size: n1 should be multiple of DIMX - " << dimX << std::endl;
		return true;
	}
	if(n2%dimY){
		std::cout << " ERROR: Invalid Grid Size: n2 should be multiple of DIMY - " << dimY << std::endl;;
		return true;
	}
	if(n3%blockZ){
		std::cout << " ERROR: Invalid Grid Size: n3 should be multiple of BLOCKZ - " << blockZ << std::endl;;
		return true;
	}

	return false;
}



/*
 * Host-Code
 * Utility function to get input arguments 
 */
void usage(std::string programName) {
  std::cout << " Incorrect parameters " << std::endl;
  std::cout << " Usage: ";
  std::cout << programName << " n1 n2 n3 b1 b2 b3 Iterations [omp|sycl] [gpu|cpu]" << std::endl << std::endl;
  std::cout << " n1 n2 n3      : Grid sizes for the stencil " << std::endl;
  std::cout << " b1 b2 b3      : cache block sizes for cpu openmp version. " << std::endl;
  std::cout << " Iterations    : No. of timesteps. " << std::endl;
  std::cout << " [omp|sycl]    : Optional: Run the OpenMP or the SYCL variant." 
            << " Default is to use both for validation " << std::endl;
  std::cout << " [gpu|cpu]     : Optional: Device to run the SYCL version" 
            << " Default is to use the GPU if available, if not fallback to CPU " << std::endl << std::endl;
}


/*
 * Host-Code
 * Utility function to print stats 
 */
void printStats(double time, size_t n1, size_t n2, size_t n3, unsigned int nIterations){

               float throughput_mpoints = 0.0f, mflops = 0.0f, normalized_time = 0.0f;
                double mbytes = 0.0f;

                normalized_time = (double)time / nIterations;
                throughput_mpoints = ((n1 - 2 * HALF_LENGTH)*(n2 - 2 * HALF_LENGTH)*(n3 - 2 * HALF_LENGTH)) / (normalized_time*1e3f);
                mflops = (7.0f*HALF_LENGTH + 5.0f)* throughput_mpoints;
                mbytes = 12.0f*throughput_mpoints;

                std::cout << "--------------------------------------" << std::endl;
                std::cout << "time         : " << time / 1e3f << " secs" << std::endl;
                std::cout << "throughput   : " << throughput_mpoints << " Mpts/s" << std::endl;
                std::cout << "flops        : " << mflops / 1e3f << " GFlops" << std::endl;
                std::cout << "bytes        : " << mbytes / 1e3f << " GBytes/s" << std::endl;
                std::cout << std::endl << "--------------------------------------" << std::endl;
                std::cout << std::endl << "--------------------------------------" << std::endl;
}


/*
 * Host-Code
 * Utility function to calculate L2-norm between resulting buffer and reference buffer 
 */
bool within_epsilon(float* output, float *reference, const size_t dimx, const size_t dimy, const size_t dimz, const unsigned int radius, const int zadjust = 0, const float delta = 0.01f)
{
	FILE* fp = fopen("./error_diff.txt", "w");
	if (!fp) fp = stderr;

	bool error  = false;
	float abs_delta = fabsf(delta);
	double norm2 = 0.0;
	for (size_t iz = 0; iz<dimz; iz++) {
		for (size_t iy = 0; iy<dimy; iy++) {
			for (size_t ix = 0; ix<dimx; ix++) {
				if (ix >= radius && ix<(dimx - radius) && iy >= radius && iy<(dimy - radius) && iz >= radius && iz<(dimz - radius + zadjust)) {
					float difference = fabsf(*reference - *output);
//					std::cout<<"diff:"<<*reference<<", "<<*output<<" - "<<difference<<std::endl;
					norm2 += difference * difference;
					if (difference > delta) {
						error = true;
						fprintf(fp," ERROR: (%zu,%zu,%zu)\t%e instead of %e (|e|=%e)\n", ix, iy, iz, *output, *reference, difference);
					}
				}
				++output;
				++reference;
			}
		}
	}

	if (fp != stderr) fclose(fp);
	norm2 = sqrt(norm2);
	if(error) printf("error (Euclidean norm): %.9e\n", norm2);
	return error;
}


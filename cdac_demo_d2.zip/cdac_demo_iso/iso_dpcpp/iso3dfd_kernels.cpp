//==============================================================
// Copyright © 2019 Intel Corporation
//
// SPDX-License-Identifier: MIT
// =============================================================

#include "iso3dfd.h"
#include "iso3dfd_iteration_device.h"

/*
 * Host-side SYCL Code
 *
 * Driver function for ISO3DFD SYCL code for CPU
 * Uses ptr_next and ptr_prev as ping-pong buffers to achieve
 * accelerated wave propogation 
 * 
 */
bool iso_3dfd_main(cl::sycl::queue& q, float* ptr_next, float* ptr_prev, float* ptr_vel, float* ptr_coeff,
	size_t n1, size_t n2, size_t n3,
	size_t bx, size_t by, size_t bz, unsigned int nIterations) {

	size_t nx = n1;
	size_t nxy = n1 * n2;
	
	//fill the body of print_device
	print_device(q);	

	size_t sizeTotal = (size_t)(nxy * n3);


	buffer<float, 1> b_ptr_next(ptr_next, range<1>{sizeTotal});
	buffer<float, 1> b_ptr_prev(ptr_prev, range<1>{sizeTotal});
	buffer<float, 1> b_ptr_vel(ptr_vel, range<1>{sizeTotal});
	buffer<float, 1> b_ptr_coeff(ptr_coeff, range<1>{HALF_LENGTH + 1});

    for(unsigned int k=0;k<nIterations;k+=1)
    {		

		q.submit([&](handler &cgh) {

			auto next = b_ptr_next.get_access<access::mode::read_write>(cgh);
			auto prev = b_ptr_prev.get_access<access::mode::read_write>(cgh);
			auto vel = b_ptr_vel.get_access<access::mode::read>(cgh);
			auto coeff = b_ptr_coeff.get_access<access::mode::read, access::target::constant_buffer>(cgh);



			auto local_nd_range = range<3>(bx, by, bz);
			auto global_nd_range = range<3>((n1-2*HALF_LENGTH), (n2-2*HALF_LENGTH), (n3 - 2 * HALF_LENGTH)); 
	
			if(k % 2 == 0)	
				cgh.parallel_for<class iso_3dfd_kernel_cpu>(
					nd_range<3>{global_nd_range, local_nd_range},
				[=](nd_item<3> it) {
				iso3dfd_iteration_device(it, next.get_pointer(), prev.get_pointer(),
		vel.get_pointer(), coeff.get_pointer(),
					nx, nxy, bx, by, bz);
				});
			else
				cgh.parallel_for<class iso_3dfd_kernel_cpu_2>(
					nd_range<3>{global_nd_range, local_nd_range},
				[=](nd_item<3> it) {
				iso3dfd_iteration_device(it, prev.get_pointer(), next.get_pointer(),
					vel.get_pointer(), coeff.get_pointer(),
					nx, nxy, bx, by, bz);
				});							

		});

	}
	return true;

}
